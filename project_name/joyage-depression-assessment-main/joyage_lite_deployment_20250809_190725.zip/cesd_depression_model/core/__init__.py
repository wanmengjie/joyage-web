"""
Core pipeline module
"""

from .main_pipeline import CESDPredictionPipeline
 
__all__ = ['CESDPredictionPipeline'] 